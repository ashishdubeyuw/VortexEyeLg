const LiveUpdater = (() => {
    const VER_KEY = 've_bundle_ver';
    const UPDATE_BANNER_ID = 've-update-banner';

    // ── Config ── change VERSION_URL to wherever you host version.json
    const VERSION_URL = 'https://raw.githubusercontent.com/ashishdubeyuw/VortexEyeLg/main/version.json';
    const CHECK_INTERVAL_MS = 60 * 1000; // check every 60 s while app is open

    let _timer = null;

    /** Persistent version stored on device */
    const localVer = () => localStorage.getItem(VER_KEY) || '1.1.0';
    const saveVer = (v) => localStorage.setItem(VER_KEY, v);

    /** Simple semver compare: 1 if a > b, -1 if a < b, 0 equal */
    function cmpVer(a, b) {
        const pa = a.split('.').map(Number);
        const pb = b.split('.').map(Number);
        for (let i = 0; i < 3; i++) {
            if ((pa[i] || 0) > (pb[i] || 0)) return 1;
            if ((pa[i] || 0) < (pb[i] || 0)) return -1;
        }
        return 0;
    }

    /** Show inline banner while update downloads */
    function showBanner(msg, type = 'info') {
        let el = document.getElementById(UPDATE_BANNER_ID);
        if (!el) {
            el = document.createElement('div');
            el.id = UPDATE_BANNER_ID;
            el.style.cssText = [
                'position:fixed', 'top:0', 'left:0', 'right:0', 'z-index:99999',
                'padding:10px 16px', 'font:600 13px/1.4 system-ui,sans-serif',
                'text-align:center', 'transition:background .3s'
            ].join(';');
            document.body.prepend(el);
        }
        const colors = { info: '#6366f1', ok: '#22c55e', err: '#ef4444' };
        el.style.background = colors[type] || colors.info;
        el.style.color = '#fff';
        el.textContent = msg;
        el.style.display = 'block';
    }

    function hideBanner() {
        const el = document.getElementById(UPDATE_BANNER_ID);
        if (el) el.style.display = 'none';
    }

    /** Fetch the remote version manifest */
    async function fetchManifest() {
        const res = await fetch(`${VERSION_URL}?t=${Date.now()}`, { cache: 'no-store' });
        if (!res.ok) throw new Error(`Manifest fetch failed: ${res.status}`);
        return res.json(); // { version, url }
    }

    /**
     * Download zip and extract files via JSZip
     * Writes into Capacitor Filesystem if available, else in-memory reload
     */
    async function downloadAndApply(zipUrl, newVer) {
        showBanner('⬇️ Downloading update…');
        const res = await fetch(zipUrl);
        if (!res.ok) throw new Error(`Zip download failed: ${res.status}`);

        const buf = await res.arrayBuffer();
        showBanner('📦 Applying update…');

        // If Capacitor Filesystem is available (native shell), write to app webDir
        if (window.Capacitor?.isNativePlatform() && window.Capacitor?.Plugins?.Filesystem) {
            await applyViaFilesystem(buf);
        }

        // Persist new version and reload the WebView
        saveVer(newVer);
        showBanner('✅ Update applied! Reloading…', 'ok');
        await delay(1000);
        window.location.reload(true);
    }

    /** Write extracted zip files to Capacitor Filesystem */
    async function applyViaFilesystem(arrayBuf) {
        // JSZip is loaded globally from CDN in index.html
        const zip = await JSZip.loadAsync(arrayBuf);
        const { Filesystem, Directory } = window.Capacitor.Plugins;

        const writes = [];
        zip.forEach((relPath, file) => {
            if (file.dir) return;
            writes.push(
                file.async('base64').then(data =>
                    Filesystem.writeFile({
                        path: relPath,
                        data,
                        directory: Directory.Data,
                        recursive: true
                    })
                )
            );
        });
        await Promise.all(writes);
    }

    const delay = (ms) => new Promise(r => setTimeout(r, ms));

    /** Main entry: check remote manifest, apply update if newer */
    async function checkForUpdate(silent = false) {
        try {
            const manifest = await fetchManifest();
            const { version: remoteVer, url: zipUrl } = manifest;

            if (cmpVer(remoteVer, localVer()) > 0) {
                console.log(`[LiveUpdater] New version: ${remoteVer}`);
                await downloadAndApply(zipUrl, remoteVer);
            } else {
                if (!silent) console.log(`[LiveUpdater] Up to date (${localVer()})`);
                hideBanner();
            }
        } catch (err) {
            console.warn('[LiveUpdater] Update check failed:', err.message);
            hideBanner();
        }
    }

    /** Start periodic polling */
    function startPolling() {
        if (_timer) return;
        _timer = setInterval(() => checkForUpdate(true), CHECK_INTERVAL_MS);
    }

    /** Public API */
    return {
        init() {
            checkForUpdate(false);  // eager check on launch
            startPolling();
        },
        checkNow: () => checkForUpdate(false),
        currentVersion: localVer
    };
})();
