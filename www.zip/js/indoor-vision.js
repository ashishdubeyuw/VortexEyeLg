/**
 * VortexEye - Indoor Vision Module
 * Camera-based object detection with OCR for sign reading
 * Uses YOLOv8 concepts (simulated for MVP, real model in Phase 2)
 */

class IndoorVision {
    constructor() {
        this.videoElement = null;
        this.canvasElement = null;
        this.ctx = null;
        this.stream = null;
        this.isRunning = false;
        this.currentTarget = null;
        this.detections = [];
        this.onDetectionCallback = null;

        // Scan-phase gate — user must rotate camera before detection fires
        this._scanRequired = false;
        this._scanComplete = false;
        this._scanRotation = 0;       // accumulated °
        this._scanThreshold = 40;     // degrees needed
        this._lastAlpha = null;       // last deviceorientation alpha
        this._onOrientation = null;   // listener ref for cleanup

        // Sequence parameters for navigation_default
        this.navSequence = ['door', 'exit_sign', 'signboard', 'elevator'];
        this.currentSequenceIndex = 0;
        this.detectionCount = 0;
        this.requiredDetectionsToAdvance = 5;

        // Detection classes for indoor navigation
        this.CLASSES = {
            0: { name: 'exit_sign', emoji: '🚪', label: 'Exit' },
            1: { name: 'door', emoji: '🚪', label: 'Door' },
            2: { name: 'elevator', emoji: '🛗', label: 'Elevator' },
            3: { name: 'stairs', emoji: '🪜', label: 'Stairs' },
            4: { name: 'emergency_exit', emoji: '🆘', label: 'Emergency Exit' },
            5: { name: 'restroom', emoji: '🚻', label: 'Restroom' },
            6: { name: 'signboard', emoji: '🪧', label: 'Sign' },
            7: { name: 'lollipop', emoji: '🍭', label: 'Lollipop' },
            8: { name: 'lolipop', emoji: '🍭', label: 'Lollipop' }
        };

        this.simulatedDetections = [];
        this.STRIDE_LENGTH_METERS = 0.75;

        // AR Debounce/Smoothing State
        this.activeDetections = []; // Stores persistent boxes
        this.DETECTION_LIFETIME_MS = 1500; // How long a box lives after model loses it
        this.INTERPOLATION_SPEED = 0.15; // Speed for box smoothing
    }


    /**
     * Convert meters to approximate walking steps
     * Uses average stride length of 0.75m
     */
    metersToSteps(meters) {
        return Math.round(meters / this.STRIDE_LENGTH_METERS);
    }

    /**
     * Initialize camera
     */
    async initCamera() {
        // Reuse existing stream — prevents double-init stall on Android/iOS
        if (this.stream && this.stream.active) {
            console.log('📸 Camera already active, reusing stream');
            return true;
        }

        this.videoElement = document.getElementById('cameraFeed');
        this.canvasElement = document.getElementById('detectionCanvas');

        if (!this.videoElement || !this.canvasElement) {
            throw new Error('Video or canvas element not found');
        }

        this.ctx = this.canvasElement.getContext('2d');

        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
                audio: false
            });

            this.videoElement.srcObject = this.stream;

            // Wait for actual pixel dimensions — loadedmetadata fires too early on mobile
            await new Promise(resolve => {
                const sync = () => {
                    if (this.videoElement.videoWidth > 0) {
                        this._syncCanvasSize();
                        resolve();
                    }
                };
                this.videoElement.addEventListener('playing', sync, { once: true });
                this.videoElement.addEventListener('canplay', sync, { once: true });
                // Polling fallback for browsers that skip both events
                const poll = setInterval(() => {
                    if (this.videoElement.videoWidth > 0) {
                        clearInterval(poll);
                        this._syncCanvasSize();
                        resolve();
                    }
                }, 100);
                // Begin playback
                this.videoElement.play().catch(() => { });
            });

            // Keep canvas in sync with video size on orientation/layout changes
            this._attachResizeObserver();

            console.log(`📸 Camera initialized (${this.canvasElement.width}×${this.canvasElement.height})`);
            return true;
        } catch (err) {
            console.error('Camera error:', err);
            throw err;
        }
    }

    /** Sync canvas pixel dimensions to video element dimensions */
    _syncCanvasSize() {
        const w = this.videoElement.videoWidth || this.videoElement.clientWidth;
        const h = this.videoElement.videoHeight || this.videoElement.clientHeight;
        if (w > 0 && h > 0 && (this.canvasElement.width !== w || this.canvasElement.height !== h)) {
            this.canvasElement.width = w;
            this.canvasElement.height = h;
        }
    }

    /** Attach a ResizeObserver + orientationchange to keep canvas size correct */
    _attachResizeObserver() {
        if (this._resizeObserver) return;
        const onResize = () => this._syncCanvasSize();
        if (window.ResizeObserver) {
            this._resizeObserver = new ResizeObserver(onResize);
            this._resizeObserver.observe(this.videoElement);
        }
        window.addEventListener('orientationchange', () => setTimeout(onResize, 300));
        window.addEventListener('resize', onResize);
    }

    /**
     * Start detection loop
     */
    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        this.detectionLoop();
        console.log('🔍 Indoor vision started');
    }

    /**
     * Stop detection loop
     */
    stop() {
        this.isRunning = false;

        if (this.stream) {
            this.stream.getTracks().forEach(t => t.stop());
            this.stream = null;
        }

        if (this._resizeObserver) {
            this._resizeObserver.disconnect();
            this._resizeObserver = null;
        }

        this._stopOrientationTracking();
        this._scanComplete = false;
        this._scanRotation = 0;

        console.log('🔍 Indoor vision stopped');
    }

    /**
     * Main detection loop
     */
    detectionLoop() {
        if (!this.isRunning) return;

        this._syncCanvasSize();
        const W = this.canvasElement.width;
        const H = this.canvasElement.height;

        if (!this.ctx || W === 0 || H === 0) {
            requestAnimationFrame(() => this.detectionLoop());
            return;
        }

        this.ctx.clearRect(0, 0, W, H);

        // Corner frame
        const cL = 22;
        this.ctx.strokeStyle = this._scanComplete ? '#10b981' : '#6366f1';
        this.ctx.lineWidth = 3;
        this.ctx.globalAlpha = 0.55;
        [[0, 0, 1, 1], [W, 0, -1, 1], [0, H, 1, -1], [W, H, -1, -1]].forEach(([x, y, dx, dy]) => {
            this.ctx.beginPath();
            this.ctx.moveTo(x + dx * cL, y);
            this.ctx.lineTo(x, y);
            this.ctx.lineTo(x, y + dy * cL);
            this.ctx.stroke();
        });
        this.ctx.globalAlpha = 1.0;

        // Scan phase: draw a progress arc in the centre
        if (this.currentTarget && !this._scanComplete) {
            this._drawScanProgress(W, H);
        } else {
            this.detectObjects();
            this.drawDetections();

            // No-detection feedback (only after scan is done)
            if (this.currentTarget && this.detections.length === 0 && this.onDetectionCallback) {
                const now = Date.now();
                if (!this._lastNoDetTime || now - this._lastNoDetTime >= 3000) {
                    this._lastNoDetTime = now;
                    this.onDetectionCallback(null);
                }
            }
        }

        requestAnimationFrame(() => this.detectionLoop());
    }

    /** Draw animated arc showing scan rotation progress */
    _drawScanProgress(W, H) {
        const cx = W / 2, cy = H / 2;
        const r = Math.min(W, H) * 0.18;
        const progress = this._scanRotation / this._scanThreshold;
        const startAngle = -Math.PI / 2;
        const endAngle = startAngle + (2 * Math.PI * progress);

        // Track ring
        this.ctx.beginPath();
        this.ctx.arc(cx, cy, r, 0, 2 * Math.PI);
        this.ctx.strokeStyle = 'rgba(99,102,241,0.25)';
        this.ctx.lineWidth = 6;
        this.ctx.stroke();

        // Fill arc
        this.ctx.beginPath();
        this.ctx.arc(cx, cy, r, startAngle, endAngle);
        this.ctx.strokeStyle = '#6366f1';
        this.ctx.lineWidth = 6;
        this.ctx.stroke();

        // Center label
        const pct = Math.round(progress * 100);
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = `bold ${Math.max(14, W * 0.045)}px Inter,sans-serif`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${pct}%`, cx, cy + 6);
        this.ctx.font = `${Math.max(11, W * 0.032)}px Inter,sans-serif`;
        this.ctx.fillStyle = 'rgba(255,255,255,0.75)';
        this.ctx.fillText('Rotate slowly', cx, cy + r + 22);
        this.ctx.textAlign = 'left';
    }

    /**
     * Detect objects in current frame
     * MVP: Simulated detection, Phase 2: Real YOLOv8 with OCR
     */
    detectObjects() {
        if (!this.currentTarget && !this.simulatedObstacle) { this.detections = []; this.activeDetections = []; return; }
        if (!this._scanComplete && !this.simulatedObstacle) return; // blocked until user scans

        // Check for simulated obstacle (Highest Priority)
        if (this.simulatedObstacle) {
            if (Math.random() < 0.2) {
                this.triggerObstacleWarning();
                return;
            }
        }

        const now = Date.now();
        let newDetections = [];

        // Simulate detection appearance (Model Run)
        // With debouncing, we don't need a high spawn rate to keep UI alive
        if (Math.random() < 0.20) {
            let classInfo;
            if (this.currentTarget === 'navigation_default') {
                const currentSequenceTarget = this.navSequence[this.currentSequenceIndex];
                classInfo = this.getClassByTargetName(currentSequenceTarget);
            } else {
                classInfo = this.getClassByTargetName(this.currentTarget);
            }

            if (classInfo) {
                const width = this.canvasElement.width;
                const height = this.canvasElement.height;

                const bboxX = width * (0.2 + Math.random() * 0.3);
                const bboxWidth = width * (0.2 + Math.random() * 0.1);
                const bboxY = height * (0.2 + Math.random() * 0.3);
                const bboxHeight = height * (0.2 + Math.random() * 0.1);
                const objectCenterX = bboxX + bboxWidth / 2;

                const directionInfo = this.calculateDirection(objectCenterX);

                // Extract OCR / Wall Text for Signboard
                let ocrText = null;
                if (classInfo.name === 'signboard') {
                    const fakeOCR = ['Meeting Room A', 'Cafeteria', 'Level 2', 'Restrooms', 'Exit', 'Stairs'];
                    ocrText = fakeOCR[Math.floor(Math.random() * fakeOCR.length)];
                }

                newDetections.push({
                    id: classInfo.id, // simple tracking id
                    classId: classInfo.id,
                    className: classInfo.name,
                    label: classInfo.label,
                    emoji: classInfo.emoji,
                    confidence: 0.85 + Math.random() * 0.1,
                    bbox: { x: bboxX, y: bboxY, width: bboxWidth, height: bboxHeight },
                    direction: directionInfo.direction,
                    directionInfo: directionInfo,
                    distanceMeters: Math.floor(3 + Math.random() * 8),
                    distance: this.metersToSteps(Math.floor(3 + Math.random() * 8)),
                    ocrText: ocrText,
                    lastSeen: now
                });

                // Handle Sequence Advancement if using navigation_default
                if (this.currentTarget === 'navigation_default') {
                    this.detectionCount++;
                    if (this.detectionCount >= this.requiredDetectionsToAdvance) {
                        this.detectionCount = 0; // reset
                        if (this.currentSequenceIndex < this.navSequence.length - 1) {
                            this.currentSequenceIndex++;
                        } else {
                            this.currentSequenceIndex = 0;
                            console.log(`🧭 Reached final target in sequence, resetting circuit.`);
                        }
                        const nextTarget = this.navSequence[this.currentSequenceIndex];
                        console.log(`🧭 Sequence Advanced: Now looking for ${nextTarget}`);
                    }
                }
            }
        }

        // --- AR Debouncing & Smoothing Logic ---
        // 1. Update existing active detections or add new ones
        newDetections.forEach(newDet => {
            const existing = this.activeDetections.find(d => d.id === newDet.id);
            if (existing) {
                // Smooth bounding box (LERP)
                existing.bbox.x += (newDet.bbox.x - existing.bbox.x) * this.INTERPOLATION_SPEED;
                existing.bbox.y += (newDet.bbox.y - existing.bbox.y) * this.INTERPOLATION_SPEED;
                existing.bbox.width += (newDet.bbox.width - existing.bbox.width) * this.INTERPOLATION_SPEED;
                existing.bbox.height += (newDet.bbox.height - existing.bbox.height) * this.INTERPOLATION_SPEED;

                // Update latest metadata instantly
                existing.confidence = newDet.confidence;
                existing.direction = newDet.direction;
                existing.directionInfo = newDet.directionInfo;
                existing.distance = newDet.distance;
                existing.distanceMeters = newDet.distanceMeters;
                existing.lastSeen = now;
                // Keep the original OCR text to avoid it changing mid-detection, but update if missing
                if (!existing.ocrText && newDet.ocrText) existing.ocrText = newDet.ocrText;
            } else {
                this.activeDetections.push(newDet);
            }
        });

        // 2. Remove expired detections
        this.activeDetections = this.activeDetections.filter(det => {
            return (now - det.lastSeen) < this.DETECTION_LIFETIME_MS;
        });

        // 3. Export active detections for drawing & callbacks
        this.detections = [...this.activeDetections];

        if (this.onDetectionCallback && this.detections.length > 0) {
            // Find the most recently seen one for guidance callback
            const primary = this.detections.reduce((prev, current) => (prev.lastSeen > current.lastSeen) ? prev : current);

            if (!this._lastCbTime || now - this._lastCbTime >= 2000) {
                this._lastCbTime = now;
                this._lastNoDetTime = now;
                this.onDetectionCallback(primary);
            }
        }
    }

    /**
     * Get class info by target name
     */
    getClassByTargetName(targetName) {
        const target = targetName.toLowerCase();

        for (const [id, classInfo] of Object.entries(this.CLASSES)) {
            if (classInfo.name.includes(target) ||
                classInfo.label.toLowerCase().includes(target) ||
                target.includes(classInfo.label.toLowerCase())) {
                return { id: parseInt(id), ...classInfo };
            }
        }

        // Default to exit sign for unknown targets
        return { id: 0, ...this.CLASSES[0] };
    }

    /**
     * Calculate direction and degrees based on object position in frame
     * Uses camera FOV to determine actual turning angle
     */
    calculateDirection(objectCenterX) {
        const frameCenter = this.canvasElement.width / 2;
        const frameWidth = this.canvasElement.width;

        // Assume ~60° horizontal FOV for typical phone camera
        const HORIZONTAL_FOV = 60;

        // Calculate offset from center (-0.5 to 0.5)
        const offsetRatio = (objectCenterX - frameCenter) / frameWidth;

        // Convert to degrees (-30° to +30° for 60° FOV)
        const angleDegrees = Math.round(offsetRatio * HORIZONTAL_FOV);

        // Determine direction category
        let direction;
        let instruction;

        if (Math.abs(angleDegrees) <= 10) {
            direction = 'ahead';
            instruction = 'Go straight ahead';
        } else if (angleDegrees < -10 && angleDegrees >= -30) {
            direction = 'slight_left';
            instruction = `Turn ${Math.abs(angleDegrees)}° left`;
        } else if (angleDegrees > 10 && angleDegrees <= 30) {
            direction = 'slight_right';
            instruction = `Turn ${angleDegrees}° right`;
        } else if (angleDegrees < -30) {
            direction = 'left';
            instruction = `Turn ${Math.abs(angleDegrees)}° left`;
        } else {
            direction = 'right';
            instruction = `Turn ${angleDegrees}° right`;
        }

        return {
            direction,
            angleDegrees,
            instruction
        };
    }

    /**
     * Calculate turn instruction when target is NOT in frame
     * Called when user needs to scan/rotate to find target
     */
    getScanInstruction(lastKnownDirection) {
        const instructions = {
            'left': 'Turn 90° left and scan',
            'right': 'Turn 90° right and scan',
            'behind': 'Turn around (180°) and scan',
            'unknown': 'Rotate slowly to scan surroundings'
        };
        return instructions[lastKnownDirection] || instructions['unknown'];
    }

    /**
     * Draw detection boxes and AR labels
     */
    drawDetections() {
        this.detections.forEach(det => {
            const { bbox, label, confidence, direction, distance, emoji, ocrText } = det;

            // 1. Draw glowing bounding box
            this.ctx.strokeStyle = 'rgba(99, 102, 241, 0.8)';
            this.ctx.lineWidth = 2;
            this.ctx.shadowColor = '#6366f1';
            this.ctx.shadowBlur = 15;
            this.ctx.strokeRect(bbox.x, bbox.y, bbox.width, bbox.height);
            this.ctx.shadowBlur = 0;

            // Draw corner accents (Futuristic HUD feel)
            const cornerLength = 20;
            this.ctx.strokeStyle = '#10b981'; // Success Green
            this.ctx.lineWidth = 4;

            // Top-left
            this.ctx.beginPath();
            this.ctx.moveTo(bbox.x, bbox.y + cornerLength);
            this.ctx.lineTo(bbox.x, bbox.y);
            this.ctx.lineTo(bbox.x + cornerLength, bbox.y);
            this.ctx.stroke();

            // Top-right
            this.ctx.beginPath();
            this.ctx.moveTo(bbox.x + bbox.width - cornerLength, bbox.y);
            this.ctx.lineTo(bbox.x + bbox.width, bbox.y);
            this.ctx.lineTo(bbox.x + bbox.width, bbox.y + cornerLength);
            this.ctx.stroke();

            // Bottom-left
            this.ctx.beginPath();
            this.ctx.moveTo(bbox.x, bbox.y + bbox.height - cornerLength);
            this.ctx.lineTo(bbox.x, bbox.y + bbox.height);
            this.ctx.lineTo(bbox.x + cornerLength, bbox.y + bbox.height);
            this.ctx.stroke();

            // Bottom-right
            this.ctx.beginPath();
            this.ctx.moveTo(bbox.x + bbox.width - cornerLength, bbox.y + bbox.height);
            this.ctx.lineTo(bbox.x + bbox.width, bbox.y + bbox.height);
            this.ctx.lineTo(bbox.x + bbox.width, bbox.y + bbox.height - cornerLength);
            this.ctx.stroke();

            // 2. Format AR Label content
            const confPct = Math.round(confidence * 100);
            const titleText = ocrText ? `[OCR TEXT] ${ocrText.toUpperCase()}` : `${emoji || ''} ${label.toUpperCase()}`;
            const subText = `${distance}m · ${direction.toUpperCase()} · ${confPct}%`;

            // Measure text for background sizing
            this.ctx.font = 'bold 16px Inter, sans-serif';
            const titleWidth = this.ctx.measureText(titleText).width;

            this.ctx.font = '500 12px Inter, sans-serif';
            const subWidth = this.ctx.measureText(subText).width;

            const boxWidth = Math.max(titleWidth, subWidth) + 32; // 16px padding each side
            const boxHeight = 54;

            // 3. Determine AR Tag Position (Floating above or below object)
            // Try to place it above, if too close to top edge, place below
            let tagY = bbox.y - boxHeight - 20;
            let pointerY = bbox.y;

            if (tagY < 10) {
                tagY = bbox.y + bbox.height + 20;
                pointerY = bbox.y + bbox.height;
            }

            const tagX = bbox.x + (bbox.width / 2) - (boxWidth / 2);

            // 4. Draw pointer line (connects box to tag)
            this.ctx.beginPath();
            this.ctx.moveTo(bbox.x + (bbox.width / 2), pointerY);
            this.ctx.lineTo(bbox.x + (bbox.width / 2), tagY + (tagY < bbox.y ? boxHeight : 0));
            this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
            this.ctx.lineWidth = 2;
            this.ctx.setLineDash([4, 4]); // Dashed line for high-tech feel
            this.ctx.stroke();
            this.ctx.setLineDash([]); // Reset

            // 5. Draw AR Tag Background (Glassmorphism effect)
            this.ctx.fillStyle = 'rgba(10, 10, 26, 0.85)'; // Dark futuristic BG
            this.ctx.strokeStyle = 'rgba(99, 102, 241, 0.6)'; // Accent border
            this.ctx.lineWidth = 1.5;

            // Rounded rectangle helper
            this.ctx.beginPath();
            this.ctx.roundRect(tagX, tagY, boxWidth, boxHeight, 8);
            this.ctx.fill();
            this.ctx.stroke();

            // 6. Draw AR Tag Text
            // Title (Object Name)
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = 'bold 16px Inter, sans-serif';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(titleText, tagX + (boxWidth / 2), tagY + 24);

            // Subtext (Distance, Direction, Confidence)
            this.ctx.fillStyle = '#10b981'; // Success Green for tracking
            this.ctx.font = '500 12px Inter, sans-serif';
            this.ctx.fillText(subText, tagX + (boxWidth / 2), tagY + 44);

            // Reset text align for other draws
            this.ctx.textAlign = 'left';
        });
    }

    /**
     * Set target to search for
     */
    setTarget(target) {
        this.currentTarget = target;
        this.detections = [];
        this._lastCbTime = null;
        this._lastNoDetTime = null;

        // Require fresh scan for every new target
        this._scanComplete = false;
        this._scanRotation = 0;
        this._lastAlpha = null;
        this._startOrientationTracking();

        if (target === 'navigation_default') {
            this.currentSequenceIndex = 0;
            this.detectionCount = 0;
        }
        console.log(`🎯 Target set: ${target} — scan required`);
    }

    /** Begin tracking device rotation via deviceorientation */
    _startOrientationTracking() {
        this._stopOrientationTracking();
        this._onOrientation = (e) => {
            if (this._scanComplete || e.alpha === null) return;
            if (this._lastAlpha === null) { this._lastAlpha = e.alpha; return; }
            let delta = Math.abs(e.alpha - this._lastAlpha);
            if (delta > 180) delta = 360 - delta;   // wrap-around correction
            this._scanRotation = Math.min(this._scanThreshold, this._scanRotation + delta);
            this._lastAlpha = e.alpha;
            if (this._scanRotation >= this._scanThreshold) {
                this._scanComplete = true;
                this._stopOrientationTracking();
                console.log('✅ Scan complete — detection enabled');
                if (this.onDetectionCallback) this.onDetectionCallback({ _scanDone: true });
            }
        };
        window.addEventListener('deviceorientation', this._onOrientation);
    }

    /** Remove orientation listener */
    _stopOrientationTracking() {
        if (this._onOrientation) {
            window.removeEventListener('deviceorientation', this._onOrientation);
            this._onOrientation = null;
        }
    }

    /**
     * Clear current target
     */
    clearTarget() {
        this.currentTarget = null;
        this.detections = [];
    }

    /**
     * Set simulated obstacle state (from Debug Panel)
     */
    setSimulatedObstacle(active) {
        this.simulatedObstacle = active;
        if (active) {
            this.triggerObstacleWarning();
        }
    }

    /**
     * Trigger an immediate obstacle warning
     */
    triggerObstacleWarning() {
        // Create a fake "Wall" detection
        const wallDetection = {
            label: 'Obstacle',
            confidence: 0.99,
            distance: 1.0, // 1 meter away
            direction: 'ahead',
            emoji: '🧱',
            isObstacle: true,
            bbox: { x: this.canvasElement.width * 0.1, y: this.canvasElement.height * 0.1, width: this.canvasElement.width * 0.8, height: this.canvasElement.height * 0.8 }
        };

        if (this.onDetectionCallback) {
            this.onDetectionCallback(wallDetection);
        }
    }

    /**
     * Set detection callback
     */
    onDetection(callback) {
        this.onDetectionCallback = callback;
    }

    /**
     * Get current detections
     */
    getDetections() {
        return this.detections;
    }

    /**
     * Generate guidance text based on detection with degree-based turning
     */
    generateGuidance(detection) {
        if (!detection) {
            return {
                icon: '🔍',
                text: `Scanning for ${this.currentTarget || 'targets'}...`,
                instruction: this.getScanInstruction('unknown')
            };
        }

        // Get direction info with degrees
        const dirInfo = detection.directionInfo || {
            direction: detection.direction,
            angleDegrees: 0,
            instruction: 'Go straight ahead'
        };

        // Build detailed guidance
        let guidance = dirInfo.instruction;
        if (detection.distance) {
            guidance += `, ${detection.distance} steps`;
        }

        // Add emoji based on direction
        let icon = detection.emoji || '🎯';
        if (dirInfo.direction.includes('left')) {
            icon = '↩️';
        } else if (dirInfo.direction.includes('right')) {
            icon = '↪️';
        } else if (dirInfo.direction === 'ahead') {
            icon = '⬆️';
        }

        return {
            icon,
            text: `${detection.label} detected: ${guidance}`,
            degrees: dirInfo.angleDegrees,
            direction: dirInfo.direction
        };
    }
}

// Export global instance
window.IndoorVision = IndoorVision;
